# DevBlinkMod
DevBlinkMod is a mod for Gorilla tag that lets everyone blink.

## Details
- The mod is client sided, only you and others with the mod can see it.
- The mod is not synched between players with the mod.
- There is no supported way of disabling the mod.

## Legal
This product is not affiliated with Gorilla Tag or Another Axiom LLC and is not endorsed or otherwise sponsored by Another Axiom LLC. Portions of the materials contained herein are property of Another Axiom LLC. ©2021 Another Axiom LLC.
