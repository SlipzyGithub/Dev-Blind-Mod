﻿namespace DevBlinkMod
{
    /// <summary>
    /// This class is used to provide information about your mod to BepInEx.
    /// </summary>
    internal class PluginInfo
    {
        public const string GUID = "com.dev9998.gorillatag.devblinkmod";
        public const string Name = "DevBlinkMod";
        public const string Version = "1.0.0";
    }
}
